export interface Users {
    // id:number;
    username:string;
    email:string;
    password:string;
}