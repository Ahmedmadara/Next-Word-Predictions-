export interface feedback {
    // id:number;
    firstname:string;
    lastname:string;
    email:string;
    message:string;
}