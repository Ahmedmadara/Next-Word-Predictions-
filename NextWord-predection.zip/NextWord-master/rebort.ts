export interface Rebort {
    // id:number;
    rebort:string;
  
}
