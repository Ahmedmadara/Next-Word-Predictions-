export class signUp{
    userName!: string;
    password : any
}